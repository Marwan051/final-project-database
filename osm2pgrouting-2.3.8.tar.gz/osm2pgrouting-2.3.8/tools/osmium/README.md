# Libosmium

Instructions to install Libosmium library on Ubuntu:

### 16.04 (Xenial)

You need to install libosmium2-dev package:

```
$ apt update && apt install -y libosmium2-dev
```

Do not install libosmium-dev package. This is an old version of Libosmium and you can not use with osm2pgrouting.
